package com.dushop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuShopFrontEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
